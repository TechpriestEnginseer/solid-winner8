package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import exerelin.campaign.MiningHelperLegacy;
import java.awt.Color;
import org.lwjgl.input.Keyboard;

public class TMI_Ships extends BaseHullMod {
    private int presses = 0;
    
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float opad = 5f;
        if (ship == null) {return;}
        tooltip.setBulletedListMode(null);
        if (Keyboard.isKeyDown(Keyboard.getKeyIndex("F1"))) {
            if (presses == 0) presses++; else {presses--;}
        }
        tooltip.setBulletedListMode(null);
        if (ship != null) {
            if (presses == 0) {
                tooltip.addSectionHeading(ship.getName()+(ship.getHullSize() != null ? " ("+ship.getHullSize().toString()+")" : ""), Alignment.MID, opad);
                tooltip.beginTable(Misc.getBasePlayerColor(), Misc.getDarkPlayerColor(), Misc.getBrightPlayerColor(), 15f, Global.getSettings().getString("timid_tmi", "stat"), 220f, Global.getSettings().getString("timid_tmi", "value"), 50f, Global.getSettings().getString("timid_tmi", "change"), 80f);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "topspeed"), ship.getMutableStats().getMaxSpeed().modified, ship.getMutableStats().getMaxSpeed().base, true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "acceleration"), ship.getMutableStats().getAcceleration().modified, ship.getMutableStats().getAcceleration().base, true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "deceleration"), ship.getMutableStats().getDeceleration().modified, ship.getMutableStats().getDeceleration().base, true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "turnrate"), "°", ship.getMutableStats().getMaxTurnRate().modified, ship.getMutableStats().getMaxTurnRate().base, true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "turnacceleration"), "°", ship.getMutableStats().getTurnAcceleration().modified, ship.getMutableStats().getTurnAcceleration().base, true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "zerofluxspeed"), ship.getMutableStats().getZeroFluxSpeedBoost().modified, ship.getMutableStats().getZeroFluxSpeedBoost().base, true);
                if (ship.getMutableStats().getZeroFluxMinimumFluxLevel().modified < 1) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "zerofluxspeedthreshold"), "%", ship.getMutableStats().getZeroFluxMinimumFluxLevel().modified*100, ship.getMutableStats().getZeroFluxMinimumFluxLevel().base*100, true);} else {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "zerofluxspeedthreshold"), "%", 100, 100, true);}
                if (ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue() != 0 && ship.getShield() != null && ship.getHullSpec().getShieldSpec() != null) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "hardfluxdissipation"), (ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue() > 1 ? 1 : ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue() < 0 ? 0 : ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue())*(ship.getMutableStats().getFluxDissipation().getModifiedValue()-(ship.getMutableStats().getShieldUpkeepMult().getModifiedValue()*ship.getHullSpec().getShieldSpec().getUpkeepCost())), (ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue() > 1 ? 1 : ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue() < 0 ? 0 : ship.getMutableStats().getHardFluxDissipationFraction().getModifiedValue())*(ship.getMutableStats().getFluxDissipation().getModifiedValue()-(ship.getMutableStats().getShieldUpkeepMult().getModifiedValue()*ship.getHullSpec().getShieldSpec().getUpkeepCost())), true);}
                if (ship.getMutableStats().getEffectiveArmorBonus().computeEffective(ship.getArmorGrid().getArmorRating()) != ship.getArmorGrid().getArmorRating()) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "effectivearmor"), ship.getMutableStats().getEffectiveArmorBonus().computeEffective(ship.getArmorGrid().getArmorRating()), ship.getArmorGrid().getArmorRating(), true);}
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "enginehealth"), ship.getMutableStats().getEngineHealthBonus().computeEffective(!ship.isFrigate() ? !ship.isDestroyer() ? !ship.isCruiser() ? !ship.isCapital() ? 100f : 800f : 600f : 400f : 200f), (!ship.isFrigate() ? !ship.isDestroyer() ? !ship.isCruiser() ? !ship.isCapital() ? 100f : 800f : 600f : 400f : 200f), true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "ventspeed"), Strings.X, ship.getMutableStats().getVentRateMult().getModifiedValue(), ship.getMutableStats().getVentRateMult().base, true);
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "overload"), ship.getMutableStats().getOverloadTimeMod().computeEffective(!ship.isFrigate() ? !ship.isDestroyer() ? !ship.isCruiser() ? !ship.isCapital() ? 10f : 10f : 8f : 6f : 4f), (!ship.isFrigate() ? !ship.isDestroyer() ? !ship.isCruiser() ? !ship.isCapital() ? 10f : 10f : 8f : 6f : 4f), false);
                if (ship.getMutableStats().getDynamic().getStat(Stats.CORONA_EFFECT_MULT).getModifiedValue() != 1) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "corona"), Strings.X, ship.getMutableStats().getDynamic().getStat(Stats.CORONA_EFFECT_MULT).getModifiedValue(), ship.getMutableStats().getDynamic().getStat(Stats.CORONA_EFFECT_MULT).getBaseValue(), false);}
                if (ship.getFleetMember() != null) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fleetpoints"), ship.getFleetMember().getMemberStrength(), ship.getHullSpec().getFleetPoints(), true);}
                if (ship.getHullSpec() != null) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "crlosssec"), ship.getMutableStats().getCRLossPerSecondPercent().computeEffective(ship.getHullSpec().getCRLossPerSecond()), ship.getHullSpec().getCRLossPerSecond(), false);}
                SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "mass"), ship.getMass(), ship.getMass(), true);
                if (ship.getShield() != null) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "shieldunfoldtime"), ship.getShield().getUnfoldTime(), SoTrueBestie(ship.getShield().getArc(), ship), false);}
                if (Global.getSettings().getModManager().isModEnabled("nexerelin") && MiningHelperLegacy.getVariantMiningStrength(ship.getVariant()) != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "nex_miningstrength"), MiningHelperLegacy.getVariantMiningStrength(ship.getVariant())*(ship.getFleetMember() != null ? ship.getFleetMember().getRepairTracker().getCR()/0.7f : 1f), MiningHelperLegacy.getVariantMiningStrength(ship.getVariant()), true);}
                tooltip.addTable("", 0, opad);
                if (ship.getSystem() != null && ship.getSystem().getSpecAPI() != null && (ship.getSystem().getSpecAPI().getFluxPerUse() != 0 || ship.getSystem().getSpecAPI().getFluxPerUseBaseRate() != 0 || ship.getSystem().getSpecAPI().getFluxPerUseBaseCap() != 0 || ship.getSystem().getSpecAPI().getFluxPerSecond() != 0 || ship.getSystem().getSpecAPI().getFluxPerSecondBaseRate() != 0 || ship.getSystem().getSpecAPI().getFluxPerSecondBaseCap() != 0)) {tooltip.addSectionHeading(Global.getSettings().getString("timid_tmi", "shipsystem") + " ("+ship.getSystem().getDisplayName()+")", Alignment.MID, opad);
                    tooltip.beginTable(Misc.getBasePlayerColor(), Misc.getDarkPlayerColor(), Misc.getBrightPlayerColor(), 15f, Global.getSettings().getString("timid_tmi", "stat"), 220f, Global.getSettings().getString("timid_tmi", "value"), 130f);
                    if (ship.getSystem().getSpecAPI().getFluxPerUse() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxuse"), "", ship.getSystem().getSpecAPI().getFluxPerUse());}
                    if (ship.getSystem().getSpecAPI().getFluxPerUseBaseRate() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxuserate"), "", ship.getSystem().getSpecAPI().getFluxPerUseBaseRate()*ship.getHullSpec().getFluxDissipation());}
                    if (ship.getSystem().getSpecAPI().getFluxPerUseBaseCap() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxusecap"), "", ship.getSystem().getSpecAPI().getFluxPerUseBaseCap()*ship.getHullSpec().getFluxCapacity());}
                    if (ship.getSystem().getSpecAPI().getFluxPerSecond() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxsec"), "", ship.getSystem().getSpecAPI().getFluxPerSecond());}
                    if (ship.getSystem().getSpecAPI().getFluxPerSecondBaseRate() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxsecrate"), "", ship.getSystem().getSpecAPI().getFluxPerSecondBaseRate()*ship.getHullSpec().getFluxDissipation());}
                    if (ship.getSystem().getSpecAPI().getFluxPerSecondBaseCap() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "fluxseccap"), "", ship.getSystem().getSpecAPI().getFluxPerSecondBaseCap()*ship.getHullSpec().getFluxCapacity());}
                    tooltip.addTable("", 0, opad);
                }
            }
            if (presses == 1) {
                boolean wow = false;
                tooltip.setBulletedListMode("• ");
                if (ship.getFleetMember() != null) {if (ship.getFleetMember().getBaseBuyValue() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "buyingprice"), Misc.getDGSCredits(ship.getFleetMember().getBaseBuyValue()));}
                if (ship.getFleetMember().getBaseSellValue() != 0) {SoTrueBestie(tooltip, Global.getSettings().getString("timid_tmi", "sellingprice"), Misc.getDGSCredits(ship.getFleetMember().getBaseSellValue()));}}
                tooltip.addSectionHeading(Global.getSettings().getString("timid_tmi", "shiptags"), Alignment.MID, opad);
                if (ship.getHullSpec() != null && !ship.getHullSpec().getTags().isEmpty()) {
                    for (String tag: ship.getHullSpec().getTags()) {
                        SoTrueBestie(tooltip, tag);
                    }
                    wow = true;
                }
                if (ship.getHullSpec() != null && !ship.getHullSpec().getHints().isEmpty()) {
                    for (ShipHullSpecAPI.ShipTypeHints hint : ship.getHullSpec().getHints()) {
                        SoTrueBestie(tooltip, hint.toString());
                    }
                    wow = true;
                }
                if (!wow) {tooltip.addPara(Global.getSettings().getString("timid_tmi", "sotruebestie"), opad);}
                tooltip.setBulletedListMode(null);
            }
        }
        tooltip.addPara(Global.getSettings().getString("timid_tmi", "F1Please"), Misc.getGrayColor(), opad);
    }
    
    private void SoTrueBestie(TooltipMakerAPI tooltip, String string) {
        if (!Global.getSettings().getString("timid_tmi", string).equals(String.format(Global.getSettings().getString("timid_tmi", "tmi_debug"), string))) {String text = Global.getSettings().getString("timid_tmi", string);tooltip.addPara(String.format("%s: %s", string, text), 2f, Misc.getHighlightColor(), string);}
        else {tooltip.addPara(String.format("%s", string), 2f, Misc.getHighlightColor(), string);}
    }
    
    private void SoTrueBestie(TooltipMakerAPI tooltip, String string, String string2) {
        tooltip.addPara(String.format("%s: %s", string, string2), 2f, Misc.getHighlightColor(), string, string2);
    }
    
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, float float1, float float2, boolean truefalse) {
        return SoTrueBestie(tooltip, string, "", float1, float2, truefalse);
    }
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, String string2, float float1) {
            Color[] colors = new Color[2];
            colors[0] = Misc.getTextColor();
            colors[1] = Misc.getHighlightColor();
            String text1 = Misc.getRoundedValue(float1)+string2;
            return tooltip.addRow(Alignment.LMID, colors[0], string, Alignment.RMID, colors[1], text1);
    }
    
    private Object SoTrueBestie(TooltipMakerAPI tooltip, String string, String string2, float float1, float float2, boolean truefalse) {
        Color[] colors = new Color[3];
        colors[0] = Misc.getTextColor();
        colors[1] = Misc.getHighlightColor();
        colors[2] = truefalse ? float1 > float2 ?  Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor() : float1 < float2 ?  Misc.getPositiveHighlightColor() : Misc.getNegativeHighlightColor();
        String text1 = Misc.getRoundedValue(float1)+string2;
        //String text2 = (truefalse ? float1 > float2 ? "(+"+Misc.getRoundedValue(float1-float2)+string2+")" : float1 < float2 ? "("+Misc.getRoundedValue(float1-float2)+string2+")" : "" : "");
        String text2 = (float1 != float2 ? float1 > float2 ? "(+"+Misc.getRoundedValue(float1-float2)+string2+")" : "("+Misc.getRoundedValue(float1-float2)+string2+")" : float1 < float2 ? "("+Misc.getRoundedValue(float1-float2)+string2+")" : "");
        return tooltip.addRow(Alignment.LMID, colors[0], string, Alignment.RMID, colors[1], text1, Alignment.LMID, colors[2], text2);
    }
    
    private float SoTrueBestie(float float1, ShipAPI ship) {
        return (2f * ship.getShieldRadiusEvenIfNoShield() * (float) Math.PI) * float1/360f / (100f * ship.getMutableStats().getShieldUnfoldRateMult().getBaseValue()) / (ship.getShield().getType() == ShieldType.FRONT ? 2f : 1f);
    }
    
	@Override
	public boolean shouldAddDescriptionToTooltip(HullSize hullSize, ShipAPI ship, boolean isForModSpec) {
		return false;
	}
    
    @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}

	@Override
	public boolean isApplicableToShip(ShipAPI ship) {
		return true;
	}
	
        @Override
	public String getUnapplicableReason(ShipAPI ship) {
		return null;
	}
}
