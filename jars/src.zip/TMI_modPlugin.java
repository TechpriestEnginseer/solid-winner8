package data.hullmods;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.codex.CodexDataV2;
import com.fs.starfarer.api.impl.codex.CodexDialogAPI;
import com.fs.starfarer.api.impl.codex.CodexEntryV2;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.UIPanelAPI;
import com.fs.starfarer.api.util.Misc;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TMI_modPlugin extends BaseModPlugin {
    public static Map<String, Float> YasBestie = new HashMap<>();
    public static Map<String, Float> YasBestie2 = new HashMap<>();
    @Override
    public void	onApplicationLoad() {
        Global.getSettings().doesVariantExist("weirdsettings"); //Probably won't be needed next update? https://fractalsoftworks.com/forum/index.php?topic=5061.msg366712#msg366712
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
        try {
            JSONArray spreadsheet = Global.getSettings().getMergedSpreadsheetDataForMod("id", "data/hulls/wing_data.csv", "timid_tmi");
            JSONArray spreadsheet2 = Global.getSettings().getMergedSpreadsheetDataForMod("id", "data/weapons/weapon_data.csv", "timid_tmi");
            for (int i = 0; i < spreadsheet.length(); i++) {
                if (!"".equals(spreadsheet.getJSONObject(i).getString("id"))) {
                JSONObject row = spreadsheet.getJSONObject(i);
                //if (row.get("range") != null && (row.get("range") instanceof Float)) {
                    YasBestie.put(row.getString("id"), ((float)row.optDouble("range", 4000)));
                //}
                }
            }
            for (int i = 0; i < spreadsheet2.length(); i++) {
                if (!"".equals(spreadsheet2.getJSONObject(i).getString("id"))) {
                JSONObject row2 = spreadsheet2.getJSONObject(i);
                //if (row.get("range") != null && (row.get("range") instanceof Float)) {
                    YasBestie2.put(row2.getString("id"), ((float)row2.optDouble("impact", 0)));
                //}
                }
            }
        } catch (IOException | JSONException ex) {}
    }
    
    @Override
    public void onAboutToStartGeneratingCodex() {
        super.onAboutToStartGeneratingCodex();
        CodexEntryV2 tmi_factions = new CodexEntryV2("tmi_factions", "Factions (TMI)", "graphics/factions/crest_domain.png") {
            @Override public boolean hasCustomDetailPanel() {return true;}
            @Override public boolean hasDetail() {return true;}
            @Override public void createCustomDetail(CustomPanelAPI panel, UIPanelAPI relatedEntries, CodexDialogAPI codex) {
				float opad = 10f;
				float pad = 5f;
				float width = panel.getPosition().getWidth();
				float initPad = 0f;
				float horzBoxPad = 30f;
				float tw = width - 290f - opad - horzBoxPad + 10f;
				TooltipMakerAPI text = panel.createUIElement(tw, 0, false);
                                text.setParaInsigniaLarge();
                                text.addPara(Global.getSettings().getString("timid_tmi", "help1title"), initPad);
                                text.setParaFontDefault();
                                text.addPara(Global.getSettings().getString("timid_tmi", "help1a"), pad);
                                text.addPara(Global.getSettings().getString("timid_tmi", "help1b"), pad);
                                text.addPara(Global.getSettings().getString("timid_tmi", "help1c"), pad, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "help1ca"), Global.getSettings().getString("timid_tmi", "help1cb"));
				text.addPara(Global.getSettings().getString("timid_tmi", "help1d"), pad, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "help1da"), Global.getSettings().getString("timid_tmi", "help1db"));
				text.addPara(Global.getSettings().getString("timid_tmi", "help1e"), pad);
				panel.updateUIElementSizeAndMakeItProcessInput(text);
				
				UIPanelAPI box = panel.wrapTooltipWithBox(text);
				panel.addComponent(box).inTL(0f, 0f);
				if (relatedEntries != null) {
					panel.addComponent(relatedEntries).inTR(0f, 0f);
				}
				
				float height = box.getPosition().getHeight();
				if (relatedEntries != null) {
					height = Math.max(height, relatedEntries.getPosition().getHeight());
				}
				panel.getPosition().setSize(width, height);
                }};
        CodexDataV2.ROOT.addChild(tmi_factions);
    }
    
    @Override
    public void onCodexDataGenerated() {
        try {
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmipriority.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_blank_hmodicon.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmienergy.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmifrigate.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmicruiser.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmicapitalship.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmicomposite.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmihullmods.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmihybrid.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmiindustry.png");
            Global.getSettings().loadTexture("graphics/hullmods/timid_tmisynergy.png");
        } catch (IOException ex) {
            Logger.getLogger(CodexSetup.class.getName()).log(Level.SEVERE, null, ex);
        }
        CodexSetup.run();
    }
    
    @Override
    public void onGameLoad(boolean newGame) {
        CodexSetup.rerun();
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_ships")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_wings")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_weapons")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_beams")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_missiles")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
    }
    
    @Override
    public void afterGameSave() {
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_ships")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_ships");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_wings")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_wings");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_weapons")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_weapons");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_beams")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_beams");
        if (!Global.getSector().getPlayerFaction().knowsHullMod("TMI_missiles")) Global.getSector().getPlayerFaction().addKnownHullMod("TMI_missiles");
    }
    

    @Override
    public void beforeGameSave() {
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_ships");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_wings");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_weapons");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_beams");
        Global.getSector().getPlayerFaction().removeKnownHullMod("TMI_missiles");
    }
    
}
